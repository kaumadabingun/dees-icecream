DeeS – The Ice Cream Shop | Free website starter

Files:
- index.html: complete responsive website
- assets/dees-logo.jpg: logo image provided in chat (if available)

How to preview:
1. Extract the ZIP.
2. Open index.html in Chrome, Edge, or Firefox.

How to publish free with GitHub Pages:
1. Create/sign in to a GitHub account at https://github.com/
2. Create a new public repository, e.g. dees-icecream
3. Upload index.html and the assets folder (keep the same structure).
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish and open the URL shown there.

WhatsApp number is set to 94711543030.
Menu prices are intentionally not listed yet.
This is a static website. It does not process online card payments or automatically manage stock/orders.
